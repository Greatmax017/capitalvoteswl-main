"use strict";
(() => {
var exports = {};
exports.id = 761;
exports.ids = [761];
exports.modules = {

/***/ 4074:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: external "@mailchimp/mailchimp_marketing"
const mailchimp_marketing_namespaceObject = require("@mailchimp/mailchimp_marketing");
var mailchimp_marketing_default = /*#__PURE__*/__webpack_require__.n(mailchimp_marketing_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/subscribe.js

mailchimp_marketing_default().setConfig({
    apiKey: process.env.MAILCHIMP_API_KEY,
    server: process.env.MAILCHIMP_API_SERVER
});
async function handler(req, res) {
    const { email  } = JSON.parse(req.body);
    if (!email) {
        return res.status(400).json({
            error: "Email is required "
        });
    }
    try {
        await mailchimp_marketing_default().lists.addListMember(process.env.MAILCHIMP_AUDIENCE_ID, {
            email_address: email,
            status: "pending",
            tags: [
                "waitlist"
            ]
        });
        return res.status(201).json({
            error: ""
        });
    } catch (error) {
        console.log(error);
        return res.status(error.status).json({
            error: "Bad Request"
        });
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4074));
module.exports = __webpack_exports__;

})();